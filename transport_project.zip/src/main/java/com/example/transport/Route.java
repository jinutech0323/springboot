package com.example.transport;

public class Route {
  private Long id;
  private String source;
  private String destination;
}
