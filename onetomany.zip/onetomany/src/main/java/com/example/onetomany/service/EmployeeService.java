package com.example.onetomany.service;

import com.example.onetomany.model.Employee;
import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    
    List<Employee> getAllEmployees();
    
    Optional<Employee> getEmployeeById(Long id);
}

