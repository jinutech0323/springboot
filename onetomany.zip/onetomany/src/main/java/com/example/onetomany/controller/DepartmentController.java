package com.example.onetomany.controller;

import com.example.onetomany.model.Department;
import com.example.onetomany.model.Employee;
import com.example.onetomany.service.DepartmentService;
import com.example.onetomany.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {
    
    @Autowired
    private DepartmentService departmentService;
    
    @Autowired
    private EmployeeService employeeService;
    
    // GET - Get all departments
    @GetMapping
    public List<Department> getAllDepartments() {
        return departmentService.getAllDepartments();
    }
    
    // GET - Get a department by ID
    @GetMapping("/{id}")
    public ResponseEntity<Department> getDepartmentById(@PathVariable Long id) {
        Optional<Department> department = departmentService.getDepartmentById(id);
        if (department.isPresent()) {
            return ResponseEntity.status(200).body(department.get());
        }
        return ResponseEntity.status(404).build();
    }
    
    // POST - Create a new department
    @PostMapping
    public ResponseEntity<Department> createDepartment(@RequestBody Department department) {
        Department savedDepartment = departmentService.createDepartment(department);
        return ResponseEntity.status(201).body(savedDepartment);
    }
    
    // POST - Add an employee to a department
    @PostMapping("/{departmentId}/employees")
    public ResponseEntity<Employee> addEmployeeToDepartment(
            @PathVariable Long departmentId,
            @RequestBody Employee employee) {
        try {
            Employee savedEmployee = departmentService.addEmployeeToDepartment(departmentId, employee);
            return ResponseEntity.status(201).body(savedEmployee);
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).build();
        }
    }
    
    // GET - Get all employees
    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }
    
    // GET - Get an employee by ID
    @GetMapping("/employees/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        Optional<Employee> employee = employeeService.getEmployeeById(id);
        if (employee.isPresent()) {
            return ResponseEntity.status(200).body(employee.get());
        }
        return ResponseEntity.status(404).build();
    }
}

