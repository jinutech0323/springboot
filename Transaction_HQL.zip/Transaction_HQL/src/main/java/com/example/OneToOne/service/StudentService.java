package com.example.OneToOne.service;

import com.example.OneToOne.entity.Student;
import java.util.List;

public interface StudentService {

    Student saveStudent(Student student);
    List<Student> getStudentById();
    // List<Student> getAllName(String name);
}
