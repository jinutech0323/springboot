package com.example.OneToOne.service.impl;

import com.example.OneToOne.entity.Student;
import com.example.OneToOne.exception.ResourceNotFoundException;
import com.example.OneToOne.repository.StudentRepository;
import com.example.OneToOne.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    StudentRepository studentRepository;
    @Transactional
    public Student saveStudent(Student student) {
        studentRepository.save(student);
        if(student.getDepartment().equals("AIML")){
            throw new ResourceNotFoundException("Testing");
        }
        return student;
    }

    public List<Student> getStudentById() {
        return studentRepository.findAll();
    }

    // public List<Student> getAllName(String name){
    //     return studentRepository.findAllByName(name);
    // }
}
