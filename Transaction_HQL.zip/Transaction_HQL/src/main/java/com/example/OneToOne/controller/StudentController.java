package com.example.OneToOne.controller;

import com.example.OneToOne.entity.Student;
import com.example.OneToOne.service.StudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {
    @Autowired
    StudentService studentService;

    @PostMapping
    public Student saveStudent(@RequestBody Student student) {
        return studentService.saveStudent(student);
    }

    @GetMapping
    public List<Student> getStudentById() {
        return studentService.getStudentById();
    }

    // @GetMapping("/{name}")
    // public List<Student> getAllByName(@PathVariable String name){
    //     return studentService.getAllName(name);
    // }
}
