package com.example.OneToOne.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.OneToOne.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {

    // @Query("FROM Student s where s.name = :name")
    // List<Student> findAllByName(@Param("name") String name);

    //another example not implemented
    //@Query("FROM Student s where s.cgpa > :cgpa AND s.dept = :dept") 
    //List<Student> findByCgpaAndDept(@Param("cgpa") float cgpa, @Param("dept") String dept) 

}
