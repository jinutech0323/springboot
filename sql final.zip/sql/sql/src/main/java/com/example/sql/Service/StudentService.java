package com.example.sql.Service;

import java.util.List;

import com.example.sql.Entitydata.Student;

public interface StudentService {
    Student postdata(Student stu);
    List<Student> getdata();
    Student updatedata(int id,Student std);
    String deletedata(int id);



    
} 