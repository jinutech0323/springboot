package com.example.handling.controller;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.handling.entity.Student;
import com.example.handling.service.Studentservice;


@RestController
@RequestMapping("/students")

public class Studentcontroller {
@Autowired  Studentservice service;

// CREATE
@PostMapping
public ResponseEntity<Student> createStudent(@Valid @RequestBody Student student) {
return new ResponseEntity<>(service.saveStudent(student),HttpStatus.CREATED);
}
// READ ALL
@GetMapping
public List<Student> getAllStudents() {
return service.getAllStudents();
}
// READ BY ID
@GetMapping("/{id}")
public Student getStudent(@PathVariable Long id) {
return service.getStudentById(id);
}
// UPDATE
@PutMapping("/{id}")
public Student updateStudent(@PathVariable Long id,
@Valid @RequestBody Student student)
{
return service.updateStudent(id, student);
}
// DELETE
@DeleteMapping("/{id}")
public ResponseEntity<String> deleteStudent(@PathVariable Long
id) {
service.deleteStudent(id);
return ResponseEntity.ok("Student deleted successfully");
}
}