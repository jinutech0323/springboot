package com.example.handling.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import com.example.handling.entity.Student;
import com.example.handling.exception.ResourceNotFoundException;
import com.example.handling.repository.StudentRepository;
import com.example.handling.service.Studentservice;
@Service
public class Studentserviceimpl implements Studentservice {
@Autowired StudentRepository repo;

@Override
public Student saveStudent(Student student) {
return repo.save(student);
}
@Override
public Student getStudentById(Long id) {
return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student not found"));
}
@Override
public List<Student> getAllStudents() {
return repo.findAll();
}
@Override
public Student updateStudent(Long id, Student student) {
Student existing = getStudentById(id);
existing.setName(student.getName());
existing.setEmail(student.getEmail());
return repo.save(existing);
}
@Override
public void deleteStudent(Long id) {
Student student = getStudentById(id);
repo.delete(student);
}
}