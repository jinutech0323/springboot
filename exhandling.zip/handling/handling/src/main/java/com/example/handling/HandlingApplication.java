package com.example.handling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
// @SpringBootApplication
@EnableJpaRepositories("com.example.handling.repository")
@EntityScan("com.example.handling.entity")
@ComponentScan("com.example.handling")
@SpringBootApplication
public class HandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HandlingApplication.class, args);
	}

}
