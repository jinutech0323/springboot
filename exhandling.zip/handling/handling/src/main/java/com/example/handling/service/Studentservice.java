package com.example.handling.service;

import java.util.List;

import com.example.handling.entity.Student;

public interface Studentservice{
Student saveStudent(Student student);
Student getStudentById(Long id);
List<Student> getAllStudents();
Student updateStudent(Long id, Student student);
void deleteStudent(Long id);
}