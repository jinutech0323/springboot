package com.example.OneToMany.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;

@Entity
@Table(name = "department")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String hodname;
    private Integer blocknum;

    @OneToMany(mappedBy = "department")
    @JsonIgnoreProperties("department")
    private List<Student> students;

    public Department() {}
    
    public Department(Long id, String name, String hodname, Integer blocknum, List<Student> students) {
        this.id = id;
        this.name = name;
        this.hodname = hodname;
        this.blocknum = blocknum;
        this.students = students;
    }

    public String getHodname() {
        return hodname;
    }

    public void setHodname(String hodname) {
        this.hodname = hodname;
    }

    public Integer getBlocknum() {
        return blocknum;
    }

    public void setBlocknum(Integer blocknum) {
        this.blocknum = blocknum;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<Student> getStudents() { return students; }
    public void setStudents(List<Student> students) { this.students = students; }
}
