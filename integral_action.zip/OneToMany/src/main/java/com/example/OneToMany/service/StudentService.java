package com.example.OneToMany.service;

import com.example.OneToMany.entity.Student;

public interface StudentService {

    Student saveStudent(Student student);
    Student getStudentById(Long id);
    String deleteId(Long id);
}
