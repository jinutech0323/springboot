package com.example.OneToMany.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.OneToMany.entity.Student;
import com.example.OneToMany.repository.StudentRepository;
import com.example.OneToMany.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    StudentRepository studentRepository;

    @Override
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public Student getStudentById(Long id) {
        return studentRepository.findById(id).orElse(null);
    }

    @Override
    public String deleteId(Long id) {
        studentRepository.deleteById(id);
        return "Done";
    }
}
