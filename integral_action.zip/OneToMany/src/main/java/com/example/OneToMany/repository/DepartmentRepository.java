package com.example.OneToMany.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.OneToMany.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
