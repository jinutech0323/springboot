package com.example.OneToMany.service;

import com.example.OneToMany.entity.Department;

public interface DepartmentService {

    Department saveDepartment(Department department);
    Department getDepartmentById(Long id);
    String deleteId(Long id);
}
